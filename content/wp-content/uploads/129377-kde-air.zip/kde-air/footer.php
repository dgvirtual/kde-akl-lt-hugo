<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>

<div id="footer">
    <div id="footer-in" >
        <!-- If you'd like to support WordPress, having the "powered by" link somewhere on your blog is the best way; it's our only promotion or advertising. -->
        <div id="navigation">
            <?php include (TEMPLATEPATH . '/inc/footnavi.php'); ?>
        </div>
        <?php wp_footer(); ?>
        <div  class="footer_left">Copyright 2010 <?php bloginfo('title'); ?> | Designed by <a href="http://csslayer.tk"> CS Slayer</a>
        </div>
        <div  class="footer_right">
        Powered by <a href="http://wordpress.org/"> WordPress</a>
        </div>
        <div class="clear"></div>
    </div>
</div>
</body>
</html>
