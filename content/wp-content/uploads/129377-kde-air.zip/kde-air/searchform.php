<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" style="width:180px;"/>
<input type="image" src="<?php bloginfo(stylesheet_directory);?>/images/search.png" alt="search"  align="top" id="searchsubmit" />
</div>
</form>
