<ul class="sf-menu">
<?php wp_list_categories('orderby=id&show_count=0&sort_column=name&title_li=&depth=3'); ?>
</ul>